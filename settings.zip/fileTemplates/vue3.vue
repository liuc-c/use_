<script setup lang=ts>

</script>

<template>
#[[$END$]]#
</template>

<style scoped>

</style>